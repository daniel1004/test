package main

import (
	"fmt"
	"sync"
)

func do(chan1 chan int) {
	for i := 0; i < 1000; i++ {
		chan1 <- i
	}
	close(chan1)
}
func to(chan1 <-chan int, wg *sync.WaitGroup) {
	defer wg.Done()
	for mes := range chan1 {
		fmt.Println(mes)
	}

}
func main() {
	wg := sync.WaitGroup{}
	chan1 := make(chan int)
	go do(chan1)
	for i := 0; i < 10; i++ {
		wg.Add(1)
		go to(chan1, &wg)
	}
	wg.Wait()
}

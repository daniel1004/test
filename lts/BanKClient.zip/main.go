package main

import (
	"errors"
	"fmt"
	"math/rand"
	"os"
	"sync"
	"time"
)

type BankClient interface {
	Deposit(amount int)
	Withdrawal(amount int) error
	Balance() int
}
type InBankClient struct {
	mutex sync.RWMutex
	data  int
}

func NewInBankClient() *InBankClient {
	return &InBankClient{data: 0}
}
func (c *InBankClient) Deposit(amount int) {
	c.mutex.Lock()
	c.data += amount
	defer c.mutex.Unlock()
}
func (c *InBankClient) Withdrawal(amount int) error {
	c.mutex.Lock()
	defer c.mutex.Unlock()
	if amount > c.data {
		return errors.New("На вашем счете не достаточно средств\n")
	} else {
		c.data -= amount
		return nil
	}
}
func (c *InBankClient) Balance() int {
	c.mutex.RLock()
	defer c.mutex.RUnlock()
	return c.data
}
func Random() time.Duration {
	seed := time.Now().UnixNano()
	r := rand.New(rand.NewSource(seed))
	minDelay := 500 * time.Millisecond
	maxDelay := 1 * time.Second
	randomDelay := time.Duration(r.Intn(int(maxDelay.Minutes()*60*1000)-int(minDelay.Minutes()*60*1000)+1)+int(minDelay.Minutes()*60*1000)) * time.Millisecond
	return randomDelay
}
func main() {

	newClient := NewInBankClient()
	stopDeposit := false
	stopWithdrawal := false
	done := make(chan struct{})

	//Начисляем
	for i := 1; i <= 10; i++ {
		go func() {
			for {
				if stopDeposit {
					done <- struct{}{}
					return

				}
				time.Sleep(Random())
				newClient.Deposit(rand.Intn(10) + 1)

			}
		}()
	}

	//Снимаем
	for i := 1; i <= 5; i++ {
		go func() {
			for {
				if stopWithdrawal {
					done <- struct{}{}
					return
				}
				time.Sleep(Random())
				err := newClient.Withdrawal(rand.Intn(5) + 1)
				if err != nil {
					fmt.Println(err)
				}
			}
		}()
	}

	for {
		var command string
		_, err := fmt.Scan(&command)
		if err != nil {
			fmt.Println(err)
		}
		switch command {
		case "deposit":
			fmt.Println("Введите сумму добавления на счёт")
			var plusAmount int
			_, err = fmt.Scan(&plusAmount)
			if err != nil {
				fmt.Println(err)
			}
			newClient.Deposit(plusAmount)
		case "withdraw":
			fmt.Println("Ведите сумму снятия со счета")
			var minusAmount int
			_, err = fmt.Scan(&minusAmount)
			if err != nil {
				fmt.Println(err)
			}
			err = newClient.Withdrawal(minusAmount)
			if err != nil {
				fmt.Println(err)
			}
		case "balance":
			fmt.Println(newClient.Balance())
		case "exit":
			stopDeposit = true
			stopWithdrawal = true
			for i := 0; i < 15; i++ {
				<-done
			}
			os.Exit(0)
		default:
			fmt.Println("Unsupported command. You can use commands: balance, deposit, withdrawal, exit")
		}
	}
}

package main

import (
	"fmt"
	"sync"
)

func main() {
	chan1 := make(chan int)
	wg := sync.WaitGroup{}
	wg.Add(1)
	go func() {
		defer wg.Done()
		for i := 1; i <= 100; i++ {
			chan1 <- i
		}
		close(chan1)
	}()
	wg.Add(1)
	go func() {
		defer wg.Done()
		for i := 1; i <= 100; i++ {
			fmt.Println(<-chan1)
		}
	}()
	wg.Wait()
}

package main

import (
	"fmt"
	"sync"
)

const step int = 1
const endCountPosition int = 1000

func main() {
	var count int = 0
	var wg = sync.WaitGroup{}
	var l = sync.NewCond(&sync.Mutex{})

	var addOperation = func() {
		defer wg.Done()
		l.L.Lock()
		count += step
		if count == endCountPosition {
			l.Signal()
		}
		l.L.Unlock()

	}
	var intEndCounter = int(endCountPosition)
	for i := 1; i <= intEndCounter; i++ {
		wg.Add(1)
		go addOperation()
	}
	l.L.Lock()
	for count < endCountPosition {
		l.Wait()
	}
	l.L.Unlock()
	wg.Wait()
	fmt.Println(count)
}

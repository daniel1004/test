package main

import "fmt"

func main() {
	chan1 := make(chan int)
	chan2 := make(chan int)
	close(chan1)
	close(chan2)
	count1 := 0
	count2 := 0
	for i := 0; i < 1000; i++ {
		select {
		case <-chan1:
			count1++
			fmt.Println("Chan1:")
		case <-chan2:
			count2++
			fmt.Println("Chan2:")
		case <-chan1:
			count1++
			fmt.Println("Chan1:")
		}
	}
	
	a := float64(count1) / float64(count2)
	fmt.Printf("Chan1 - %d, Chan2 - %d\n", count1, count2)
	if count1 > count2 {
		fmt.Printf("channel 1 met more than channel 2 by %f\n ", a)
	}

}

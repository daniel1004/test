package main

import (
	"fmt"
	"sync"
)

func main() {
	var wg sync.WaitGroup
	for i := 1; i < 6; i++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			for j := 1; j <= 10; j++ {
				fmt.Println(j)
			}
		}()
	}
	wg.Wait()
}

package main

import (
	"fmt"
	"sync"
)

// Напишите код, в котором несколько горутин увеличивают значение целочисленного счётчика
// и синхронизируют свою работу через канал.
// Нужно предусмотреть возможность настройки количества используемых горутин и конечного значения счётчика.
// Попробуйте реализовать счётчик с элементами ООП (в виде структуры и методов структуры).
// Попробуйте реализовать динамическую проверку достижения счётчиком нужного значения.
type data struct {
	value int
	limit int
	chan1 chan struct{}
	mu    sync.Mutex
	wg    sync.WaitGroup
	done  chan bool
}

func (d *data) increment() {
	defer d.wg.Done()
	for {
		d.mu.Lock()
		if d.value >= d.limit {
			d.mu.Unlock()
			return
		}
		d.value++
		fmt.Println(d.value)
		d.mu.Unlock()
		d.chan1 <- struct{}{}
	}
}
func (d *data) Watch() {
	for {
		select {
		case <-d.chan1:
			d.mu.Lock()
			if d.value >= d.limit {
				fmt.Println("lumit")
				d.mu.Unlock()
				d.done <- true
				return
			}
			d.mu.Unlock()
		case <-d.done:
			return
		}
	}

}
func (d *data) startWorkers(num int) {
	for i := 0; i < num; i++ {
		d.wg.Add(1)
		go d.increment()
	}
	d.wg.Wait()
	close(d.chan1)
}
func main() {
	limit := 10000
	num := 30
	counter := data{
		value: 0,
		limit: limit,
		chan1: make(chan struct{}, num),
		done:  make(chan bool),
	}
	go counter.Watch()
	counter.startWorkers(num)
	<-counter.done
}

package main

import (
	"fmt"
	"sync"
	"time"
)

type Semaphore struct {
	sem     chan struct{}
	timeout time.Duration
}

func (s *Semaphore) Acquire() error {
	select {
	case s.sem <- struct{}{}:
		return nil
	case <-time.After(s.timeout):
		return fmt.Errorf("Не удалось захватить семафор")
	}
}

func (s *Semaphore) Release() error {
	select {
	case <-s.sem:
		return nil
	case <-time.After(s.timeout):
		return fmt.Errorf("Не удалось освободить семафор")
	}
}

func NewSemaphore(maxConcurrent int, timeout time.Duration) *Semaphore {
	return &Semaphore{
		sem:     make(chan struct{}, maxConcurrent),
		timeout: timeout,
	}
}

type SharedData struct {
	counter int
}

func (d *SharedData) IncrementCounter(s *Semaphore) error {
	if err := s.Acquire(); err != nil {
		return err
	}
	defer s.Release()

	d.counter++
	fmt.Println("Счетчик увеличен до:", d.counter)

	return nil
}

func main() {
	maxConcurrent := 3
	s := NewSemaphore(maxConcurrent, 3*time.Second)
	sharedData := &SharedData{}

	var wg sync.WaitGroup
	for i := 0; i < 100; i++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			if err := sharedData.IncrementCounter(s); err != nil {
				fmt.Println("Ошибка при увеличении счетчика:", err)
			}
		}()
	}

	wg.Wait()
	fmt.Println("Финальное значение счетчика:", sharedData.counter)
}

package main

import (
	"fmt"
	"sync"
	"sync/atomic"
)

const step int64 = 1
const endCountPosition int64 = 10

func main() {
	var count int64 = 0
	var wg = sync.WaitGroup{}

	var addOperation func() = func() {
		defer wg.Done()
		atomic.AddInt64(&count, step)
	}
	var intEndCounter int = int(endCountPosition)
	for i := 1; i <= intEndCounter; i++ {
		wg.Add(1)
		go addOperation()
	}
	wg.Wait()
	fmt.Println(count)
}

package main

import (
	"fmt"
	"time"
)

func main() {
	chan1 := make(chan int)
	chan2 := make(chan int)
	var t time.Time
	var ticker *time.Ticker = time.NewTicker(time.Second)
	select {
	case <-chan1:
	case <-chan2:
	default:
		for {
			t = <-ticker.C
			outputData := []byte("Время : ")
			outputData = t.AppendFormat(outputData, "15:04:05")
			fmt.Println(string(outputData))
		}

	}
}

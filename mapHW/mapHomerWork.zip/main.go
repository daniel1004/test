package main

import (
	"fmt"
	"os"
)

func main() {

	fmt.Println(duplicateSearch(Scan()))
}
func Scan() (ar, arr []int) {
	capArrOne, capArrTwo := 0, 0

	//Ввод первой длинны массива
	fmt.Println("Введите первую длинну массива")
	_, err := fmt.Scanln(&capArrOne)
	if err != nil {
		fmt.Println("Ошибка ввода. Пожалуйста, введите целое число.")
		os.Exit(1)
	}

	//Ввод второй длинны массива
	fmt.Println("Введите вторую длинну массива")
	_, err = fmt.Scanln(&capArrTwo)
	if err != nil {
		fmt.Println("Ошибка ввода. Пожалуйста, введите целое число.")
		os.Exit(1)
	}

	//Ввод значений первого массива
	arrOne := make([]int, capArrOne)
	fmt.Printf("Введите элементы массива %d", capArrOne)
	fmt.Println()
	for i := 0; i < capArrOne; i++ {
		_, err := fmt.Scanln(&arrOne[i])
		if err != nil {
			fmt.Println("Ошибка ввода. Пожалуйста, введите целое число.")
			os.Exit(1)
		}
	}

	//Ввод значений второго массива
	arrTwo := make([]int, capArrOne)
	fmt.Printf("Введите элементы массива %d", capArrTwo)
	fmt.Println()
	for i := 0; i < capArrTwo; i++ {
		_, err := fmt.Scanln(&arrTwo[i])
		if err != nil {
			fmt.Println("Ошибка ввода. Пожалуйста, введите целое число.")
			os.Exit(1)
		}
	}

	return arrOne, arrTwo
}

func duplicateSearch(one, two []int) []int {
	mappy := make(map[int]int)
	var arrDuble []int
	for _, n := range one {
		mappy[n]++
	}
	for _, n := range two {
		if _, ok := mappy[n]; ok {
			arrDuble = append(arrDuble, n)
		}
	}

	return arrDuble
}
